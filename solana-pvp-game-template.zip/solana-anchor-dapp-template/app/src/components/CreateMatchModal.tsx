'use client';

import { FC, useState } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { LAMPORTS_PER_SOL } from '@solana/web3.js';

interface CreateMatchModalProps {
  onClose: () => void;
  onCreate: (stakeAmount: number) => Promise<void>;
}

const PRESET_STAKES = [0.1, 0.25, 0.5, 1, 2, 5];

export const CreateMatchModal: FC<CreateMatchModalProps> = ({
  onClose,
  onCreate,
}) => {
  const { connection } = useConnection();
  const { publicKey } = useWallet();

  const [stakeAmount, setStakeAmount] = useState<string>('0.1');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);

  // Fetch wallet balance
  useState(() => {
    if (publicKey) {
      connection.getBalance(publicKey).then((bal) => {
        setBalance(bal / LAMPORTS_PER_SOL);
      });
    }
  });

  const handleCreate = async () => {
    const amount = parseFloat(stakeAmount);

    // Validate
    if (isNaN(amount) || amount <= 0) {
      setError('Please enter a valid stake amount');
      return;
    }

    if (amount < 0.01) {
      setError('Minimum stake is 0.01 SOL');
      return;
    }

    if (amount > 100) {
      setError('Maximum stake is 100 SOL');
      return;
    }

    if (balance !== null && amount > balance) {
      setError('Insufficient balance');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await onCreate(amount);
    } catch (err: any) {
      setError(err.message || 'Failed to create match');
    } finally {
      setLoading(false);
    }
  };

  const stakeSol = parseFloat(stakeAmount) || 0;
  const totalPot = stakeSol * 2;
  const platformFee = totalPot * 0.05;
  const winnerPrize = totalPot - platformFee;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 rounded-2xl border border-slate-700 w-full max-w-md">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-slate-700">
          <h2 className="text-xl font-bold">Create New Match</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-2xl"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Balance */}
          {balance !== null && (
            <p className="text-slate-400 text-sm mb-4">
              Your balance: <span className="text-white">{balance.toFixed(4)} SOL</span>
            </p>
          )}

          {/* Stake Input */}
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">
              Stake Amount (SOL)
            </label>
            <input
              type="number"
              value={stakeAmount}
              onChange={(e) => setStakeAmount(e.target.value)}
              min="0.01"
              max="100"
              step="0.01"
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-lg focus:outline-none focus:border-solana-purple"
              placeholder="0.1"
            />
          </div>

          {/* Preset Buttons */}
          <div className="flex flex-wrap gap-2 mb-6">
            {PRESET_STAKES.map((amount) => (
              <button
                key={amount}
                onClick={() => setStakeAmount(amount.toString())}
                className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                  parseFloat(stakeAmount) === amount
                    ? 'bg-solana-purple text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {amount} SOL
              </button>
            ))}
          </div>

          {/* Summary */}
          <div className="bg-slate-700/50 rounded-lg p-4 mb-6">
            <h3 className="text-sm font-medium mb-3 text-slate-300">
              Match Summary
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Your Stake</span>
                <span>{stakeSol.toFixed(2)} SOL</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Opponent Stake</span>
                <span>{stakeSol.toFixed(2)} SOL</span>
              </div>
              <div className="flex justify-between border-t border-slate-600 pt-2">
                <span className="text-slate-400">Total Pot</span>
                <span className="font-semibold">{totalPot.toFixed(2)} SOL</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">Platform Fee (5%)</span>
                <span className="text-slate-500">-{platformFee.toFixed(4)} SOL</span>
              </div>
              <div className="flex justify-between text-solana-green">
                <span>Winner Takes</span>
                <span className="font-bold">{winnerPrize.toFixed(4)} SOL</span>
              </div>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-4">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="btn-secondary flex-1"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              onClick={handleCreate}
              disabled={loading || stakeSol <= 0}
              className="btn-primary flex-1"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="spinner"></span>
                  Creating...
                </span>
              ) : (
                `Create Match`
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
