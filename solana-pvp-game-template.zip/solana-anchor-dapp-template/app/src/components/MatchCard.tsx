'use client';

import { FC } from 'react';
import { LAMPORTS_PER_SOL, PublicKey } from '@solana/web3.js';
import { MatchData } from '@/hooks/usePvpGame';
import { shortenAddress } from '@/utils/solana';

interface MatchCardProps {
  match: MatchData;
  onJoin?: () => void;
  onCancel?: () => void;
  onClaim?: () => void;
  isJoining?: boolean;
  isCancelling?: boolean;
  isClaiming?: boolean;
  showJoinButton?: boolean;
  showCancelButton?: boolean;
  showClaimButton?: boolean;
  currentUserKey?: PublicKey;
}

export const MatchCard: FC<MatchCardProps> = ({
  match,
  onJoin,
  onCancel,
  onClaim,
  isJoining = false,
  isCancelling = false,
  isClaiming = false,
  showJoinButton = false,
  showCancelButton = false,
  showClaimButton = false,
  currentUserKey,
}) => {
  const stakeSOL = match.stakeAmount.toNumber() / LAMPORTS_PER_SOL;
  const totalPot = stakeSOL * 2;
  const prizePot = totalPot * 0.95; // 5% fee

  const getStatusBadge = () => {
    const status = match.status;
    if ('waitingForOpponent' in status) {
      return (
        <span className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-sm">
          ⏳ Waiting for Opponent
        </span>
      );
    }
    if ('inProgress' in status) {
      return (
        <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm">
          🎮 In Progress
        </span>
      );
    }
    if ('completed' in status) {
      return (
        <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm">
          ✅ Completed
        </span>
      );
    }
    if ('claimed' in status) {
      return (
        <span className="px-3 py-1 bg-slate-500/20 text-slate-400 rounded-full text-sm">
          💸 Claimed
        </span>
      );
    }
    if ('cancelled' in status) {
      return (
        <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-sm">
          ❌ Cancelled
        </span>
      );
    }
    return null;
  };

  const isWinner =
    currentUserKey &&
    !match.winner.equals(new PublicKey(0)) &&
    match.winner.equals(currentUserKey);

  const isLoser =
    currentUserKey &&
    !match.winner.equals(new PublicKey(0)) &&
    !match.winner.equals(currentUserKey) &&
    (match.player1.equals(currentUserKey) || match.player2.equals(currentUserKey));

  return (
    <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-6 hover:border-slate-600 transition-colors">
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            {getStatusBadge()}
            {isWinner && (
              <span className="px-3 py-1 bg-solana-green/20 text-solana-green rounded-full text-sm">
                🏆 You Won!
              </span>
            )}
            {isLoser && (
              <span className="px-3 py-1 bg-red-500/20 text-red-400 rounded-full text-sm">
                😔 You Lost
              </span>
            )}
          </div>
          <p className="text-slate-400 text-sm">
            Created by {shortenAddress(match.player1)}
          </p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-solana-green">
            {stakeSOL.toFixed(2)} SOL
          </div>
          <p className="text-slate-400 text-sm">stake per player</p>
        </div>
      </div>

      {/* Match Details */}
      <div className="grid grid-cols-2 gap-4 mb-4 py-4 border-t border-b border-slate-700">
        <div>
          <p className="text-slate-400 text-sm mb-1">Player 1</p>
          <p className="font-mono text-sm">{shortenAddress(match.player1)}</p>
        </div>
        <div>
          <p className="text-slate-400 text-sm mb-1">Player 2</p>
          <p className="font-mono text-sm">
            {match.player2.equals(new PublicKey(0))
              ? '—'
              : shortenAddress(match.player2)}
          </p>
        </div>
        <div>
          <p className="text-slate-400 text-sm mb-1">Total Pot</p>
          <p className="font-semibold">{totalPot.toFixed(2)} SOL</p>
        </div>
        <div>
          <p className="text-slate-400 text-sm mb-1">Winner Prize</p>
          <p className="font-semibold text-solana-green">
            {prizePot.toFixed(3)} SOL
          </p>
        </div>
      </div>

      {/* Winner Info (if completed) */}
      {!match.winner.equals(new PublicKey(0)) && (
        <div className="mb-4 p-3 bg-solana-green/10 rounded-lg border border-solana-green/30">
          <p className="text-sm text-slate-400">Winner</p>
          <p className="font-mono text-solana-green">
            {shortenAddress(match.winner)}
          </p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3">
        {showJoinButton && (
          <button
            onClick={onJoin}
            disabled={isJoining}
            className="btn-primary flex-1"
          >
            {isJoining ? (
              <span className="flex items-center justify-center gap-2">
                <span className="spinner"></span>
                Joining...
              </span>
            ) : (
              `Join Match (${stakeSOL} SOL)`
            )}
          </button>
        )}

        {showCancelButton && (
          <button
            onClick={onCancel}
            disabled={isCancelling}
            className="btn-secondary flex-1"
          >
            {isCancelling ? (
              <span className="flex items-center justify-center gap-2">
                <span className="spinner"></span>
                Cancelling...
              </span>
            ) : (
              'Cancel & Refund'
            )}
          </button>
        )}

        {showClaimButton && isWinner && (
          <button
            onClick={onClaim}
            disabled={isClaiming}
            className="btn-primary flex-1"
          >
            {isClaiming ? (
              <span className="flex items-center justify-center gap-2">
                <span className="spinner"></span>
                Claiming...
              </span>
            ) : (
              `Claim ${prizePot.toFixed(3)} SOL`
            )}
          </button>
        )}
      </div>

      {/* Match ID (small) */}
      <p className="text-slate-500 text-xs mt-4 font-mono">
        Match: {match.publicKey.toBase58().slice(0, 16)}...
      </p>
    </div>
  );
};
