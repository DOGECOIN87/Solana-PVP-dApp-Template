'use client';

import { FC, useState, useEffect, useCallback } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { PublicKey } from '@solana/web3.js';
import { usePvpGame, MatchData } from '@/hooks/usePvpGame';
import { MatchCard } from './MatchCard';

export const MyMatches: FC = () => {
  const { publicKey } = useWallet();
  const { fetchMyMatches, cancelMatch, claimWinnings, fetchPlatformStats } = usePvpGame();

  const [matches, setMatches] = useState<MatchData[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState<string | null>(null);
  const [claiming, setClaiming] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [treasuryKey, setTreasuryKey] = useState<PublicKey | null>(null);

  const loadMatches = useCallback(async () => {
    setLoading(true);
    try {
      const [myMatches, stats] = await Promise.all([
        fetchMyMatches(),
        fetchPlatformStats(),
      ]);
      
      // Sort by creation time (newest first)
      myMatches.sort((a, b) => b.createdAt.toNumber() - a.createdAt.toNumber());
      setMatches(myMatches);
      
      // Store treasury key for claims
      if (stats) {
        // We'll need to get this from platform config
        // For now, we'll handle it in the claim function
      }
    } catch (err) {
      console.error('Error loading matches:', err);
    } finally {
      setLoading(false);
    }
  }, [fetchMyMatches, fetchPlatformStats]);

  useEffect(() => {
    if (publicKey) {
      loadMatches();
    }
  }, [publicKey, loadMatches]);

  const handleCancel = async (match: MatchData) => {
    setCancelling(match.publicKey.toBase58());
    setError(null);
    try {
      const tx = await cancelMatch(match.publicKey);
      console.log('Cancelled match:', tx);
      await loadMatches();
    } catch (err: any) {
      setError(err.message || 'Failed to cancel match');
    } finally {
      setCancelling(null);
    }
  };

  const handleClaim = async (match: MatchData) => {
    setClaiming(match.publicKey.toBase58());
    setError(null);
    try {
      // We need to fetch the treasury from platform config
      // For now, showing error - in production, fetch from platform config
      setError('Please implement treasury lookup from platform config');
      // const tx = await claimWinnings(match.publicKey, treasuryKey!);
      // console.log('Claimed winnings:', tx);
      // await loadMatches();
    } catch (err: any) {
      setError(err.message || 'Failed to claim winnings');
    } finally {
      setClaiming(null);
    }
  };

  const categorizeMatches = () => {
    const waiting: MatchData[] = [];
    const inProgress: MatchData[] = [];
    const completed: MatchData[] = [];
    const history: MatchData[] = [];

    matches.forEach((match) => {
      if ('waitingForOpponent' in match.status) {
        waiting.push(match);
      } else if ('inProgress' in match.status) {
        inProgress.push(match);
      } else if ('completed' in match.status) {
        completed.push(match);
      } else {
        history.push(match);
      }
    });

    return { waiting, inProgress, completed, history };
  };

  const { waiting, inProgress, completed, history } = categorizeMatches();

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="spinner mx-auto mb-4"></div>
        <p className="text-slate-400">Loading your matches...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Error */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4">
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Refresh Button */}
      <div className="flex justify-end">
        <button
          onClick={loadMatches}
          className="btn-secondary flex items-center gap-2"
        >
          ↻ Refresh
        </button>
      </div>

      {/* No matches */}
      {matches.length === 0 && (
        <div className="text-center py-12 bg-slate-800/30 rounded-xl border border-slate-700">
          <div className="text-5xl mb-4">📋</div>
          <h3 className="text-lg font-semibold mb-2">No Matches Yet</h3>
          <p className="text-slate-400">
            Create or join a match to get started!
          </p>
        </div>
      )}

      {/* Action Required (Completed matches where user is winner) */}
      {completed.length > 0 && (
        <Section title="🏆 Claim Your Winnings" count={completed.length}>
          {completed.map((match) => (
            <MatchCard
              key={match.publicKey.toBase58()}
              match={match}
              currentUserKey={publicKey!}
              showClaimButton={true}
              onClaim={() => handleClaim(match)}
              isClaiming={claiming === match.publicKey.toBase58()}
            />
          ))}
        </Section>
      )}

      {/* In Progress */}
      {inProgress.length > 0 && (
        <Section title="🎮 In Progress" count={inProgress.length}>
          {inProgress.map((match) => (
            <MatchCard
              key={match.publicKey.toBase58()}
              match={match}
              currentUserKey={publicKey!}
            />
          ))}
        </Section>
      )}

      {/* Waiting for Opponent */}
      {waiting.length > 0 && (
        <Section title="⏳ Waiting for Opponent" count={waiting.length}>
          {waiting.map((match) => (
            <MatchCard
              key={match.publicKey.toBase58()}
              match={match}
              currentUserKey={publicKey!}
              showCancelButton={true}
              onCancel={() => handleCancel(match)}
              isCancelling={cancelling === match.publicKey.toBase58()}
            />
          ))}
        </Section>
      )}

      {/* History */}
      {history.length > 0 && (
        <Section title="📜 Match History" count={history.length}>
          {history.map((match) => (
            <MatchCard
              key={match.publicKey.toBase58()}
              match={match}
              currentUserKey={publicKey!}
            />
          ))}
        </Section>
      )}
    </div>
  );
};

interface SectionProps {
  title: string;
  count: number;
  children: React.ReactNode;
}

const Section: FC<SectionProps> = ({ title, count, children }) => (
  <div>
    <div className="flex items-center gap-2 mb-4">
      <h3 className="text-lg font-semibold">{title}</h3>
      <span className="px-2 py-0.5 bg-slate-700 rounded-full text-sm text-slate-300">
        {count}
      </span>
    </div>
    <div className="grid gap-4">{children}</div>
  </div>
);
