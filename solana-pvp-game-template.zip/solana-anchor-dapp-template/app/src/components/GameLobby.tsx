'use client';

import { FC, useState, useEffect, useCallback } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import { usePvpGame, MatchData } from '@/hooks/usePvpGame';
import { MatchCard } from './MatchCard';
import { CreateMatchModal } from './CreateMatchModal';

export const GameLobby: FC = () => {
  const { publicKey } = useWallet();
  const { fetchOpenMatches, createMatch, joinMatch } = usePvpGame();

  const [openMatches, setOpenMatches] = useState<MatchData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [joining, setJoining] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadMatches = useCallback(async () => {
    setLoading(true);
    try {
      const matches = await fetchOpenMatches();
      // Filter out user's own matches
      const othersMatches = matches.filter(
        (m) => !m.player1.equals(publicKey!)
      );
      setOpenMatches(othersMatches);
    } catch (err) {
      console.error('Error loading matches:', err);
    } finally {
      setLoading(false);
    }
  }, [fetchOpenMatches, publicKey]);

  useEffect(() => {
    if (publicKey) {
      loadMatches();
      // Refresh every 30 seconds
      const interval = setInterval(loadMatches, 30000);
      return () => clearInterval(interval);
    }
  }, [publicKey, loadMatches]);

  const handleJoinMatch = async (match: MatchData) => {
    setJoining(match.publicKey.toBase58());
    setError(null);
    try {
      const tx = await joinMatch(match.publicKey);
      console.log('Joined match:', tx);
      // Refresh matches
      await loadMatches();
    } catch (err: any) {
      setError(err.message || 'Failed to join match');
    } finally {
      setJoining(null);
    }
  };

  const handleCreateMatch = async (stakeAmount: number) => {
    setError(null);
    try {
      const { tx, matchPDA } = await createMatch(stakeAmount);
      console.log('Created match:', tx, matchPDA.toBase58());
      setShowCreateModal(false);
      // Refresh matches
      await loadMatches();
    } catch (err: any) {
      setError(err.message || 'Failed to create match');
      throw err;
    }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold">Available Matches</h2>
          <p className="text-slate-400 text-sm">
            {openMatches.length} match{openMatches.length !== 1 ? 'es' : ''} waiting for opponents
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={loadMatches}
            className="btn-secondary flex items-center gap-2"
            disabled={loading}
          >
            ↻ Refresh
          </button>
          <button
            onClick={() => setShowCreateModal(true)}
            className="btn-primary"
          >
            + Create Match
          </button>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 mb-6">
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Match List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="spinner mx-auto mb-4"></div>
          <p className="text-slate-400">Loading matches...</p>
        </div>
      ) : openMatches.length === 0 ? (
        <div className="text-center py-12 bg-slate-800/30 rounded-xl border border-slate-700">
          <div className="text-5xl mb-4">🏟️</div>
          <h3 className="text-lg font-semibold mb-2">No Open Matches</h3>
          <p className="text-slate-400 mb-6">
            Be the first to create a match and find an opponent!
          </p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="btn-primary"
          >
            Create First Match
          </button>
        </div>
      ) : (
        <div className="grid gap-4">
          {openMatches.map((match) => (
            <MatchCard
              key={match.publicKey.toBase58()}
              match={match}
              onJoin={() => handleJoinMatch(match)}
              isJoining={joining === match.publicKey.toBase58()}
              showJoinButton={true}
            />
          ))}
        </div>
      )}

      {/* Create Match Modal */}
      {showCreateModal && (
        <CreateMatchModal
          onClose={() => setShowCreateModal(false)}
          onCreate={handleCreateMatch}
        />
      )}
    </div>
  );
};
