'use client';

import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { GameLobby } from '@/components/GameLobby';
import { MyMatches } from '@/components/MyMatches';
import { useState } from 'react';

type Tab = 'lobby' | 'my-matches';

export default function Home() {
  const { connected } = useWallet();
  const [activeTab, setActiveTab] = useState<Tab>('lobby');

  return (
    <main className="min-h-screen flex flex-col">
      <Header />

      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-8">
            <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-solana-purple to-solana-green bg-clip-text text-transparent">
              PVP Arena
            </h1>
            <p className="text-slate-400 text-lg mb-2">
              Skill-based player vs player gaming on Solana
            </p>
            <p className="text-slate-500 text-sm">
              5% platform fee • Instant payouts • Secure escrow
            </p>
          </div>

          {!connected ? (
            <div className="text-center py-16">
              <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-12 max-w-md mx-auto">
                <div className="text-6xl mb-6">🎮</div>
                <h2 className="text-2xl font-bold mb-4">Connect to Play</h2>
                <p className="text-slate-400 mb-8">
                  Connect your Solana wallet to create or join matches
                </p>
                <WalletMultiButton />
              </div>
            </div>
          ) : (
            <>
              {/* Tab Navigation */}
              <div className="flex justify-center mb-8">
                <div className="bg-slate-800/50 rounded-lg p-1 flex gap-1">
                  <button
                    onClick={() => setActiveTab('lobby')}
                    className={`px-6 py-2 rounded-md transition-all ${
                      activeTab === 'lobby'
                        ? 'bg-gradient-to-r from-solana-purple to-solana-green text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    🏟️ Game Lobby
                  </button>
                  <button
                    onClick={() => setActiveTab('my-matches')}
                    className={`px-6 py-2 rounded-md transition-all ${
                      activeTab === 'my-matches'
                        ? 'bg-gradient-to-r from-solana-purple to-solana-green text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    📋 My Matches
                  </button>
                </div>
              </div>

              {/* Tab Content */}
              {activeTab === 'lobby' && <GameLobby />}
              {activeTab === 'my-matches' && <MyMatches />}
            </>
          )}

          {/* How It Works */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-center mb-8">How It Works</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <StepCard
                number={1}
                title="Create Match"
                description="Set your stake amount and create a new match"
                icon="💰"
              />
              <StepCard
                number={2}
                title="Find Opponent"
                description="Wait for another player to join your match"
                icon="🎯"
              />
              <StepCard
                number={3}
                title="Play & Win"
                description="Compete in the skill-based game"
                icon="🎮"
              />
              <StepCard
                number={4}
                title="Claim Prize"
                description="Winner takes 95% of the total pot"
                icon="🏆"
              />
            </div>
          </div>

          {/* Features */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
            <FeatureCard
              title="Secure Escrow"
              description="All stakes held in a smart contract until the match concludes"
              icon="🔐"
            />
            <FeatureCard
              title="5% Platform Fee"
              description="Low, flat fee regardless of match outcome"
              icon="📊"
            />
            <FeatureCard
              title="Instant Payouts"
              description="Winners can claim their prize immediately on-chain"
              icon="⚡"
            />
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
}

function StepCard({
  number,
  title,
  description,
  icon,
}: {
  number: number;
  title: string;
  description: string;
  icon: string;
}) {
  return (
    <div className="text-center">
      <div className="relative inline-block">
        <div className="text-4xl mb-4">{icon}</div>
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-solana-purple rounded-full flex items-center justify-center text-xs font-bold">
          {number}
        </div>
      </div>
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-slate-400 text-sm">{description}</p>
    </div>
  );
}

function FeatureCard({
  title,
  description,
  icon,
}: {
  title: string;
  description: string;
  icon: string;
}) {
  return (
    <div className="bg-slate-800/30 border border-slate-700 rounded-xl p-6 text-center hover:bg-slate-800/50 transition-colors">
      <div className="text-4xl mb-4">{icon}</div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-slate-400 text-sm">{description}</p>
    </div>
  );
}
