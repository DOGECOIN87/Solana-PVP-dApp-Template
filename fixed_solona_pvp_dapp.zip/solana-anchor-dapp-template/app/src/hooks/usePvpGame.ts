'use client';

import { useMemo, useCallback, useState, useEffect } from 'react';
import { useWallet, useConnection, useAnchorWallet } from '@solana/wallet-adapter-react';
import { PublicKey, SystemProgram, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { Program, AnchorProvider, BN } from '@coral-xyz/anchor';
import idl from '@/idl/pvp_game.json';
import { PvpGame } from '@/idl/pvp_game';

// Program ID - update after deploying
const PROGRAM_ID = new PublicKey(idl.address);

// Seeds
const PLATFORM_CONFIG_SEED = 'platform_config';
const MATCH_SEED = 'match';
const ESCROW_SEED = 'escrow';

export interface MatchData {
  publicKey: PublicKey;
  matchId: number[];
  player1: PublicKey;
  player2: PublicKey;
  stakeAmount: BN;
  status: any;
  winner: PublicKey;
  createdAt: BN;
  startedAt: BN;
  endedAt: BN;
  feeAmount: BN;
  prizeAmount: BN;
}

export interface PlatformStats {
  totalMatches: BN;
  matchesCompleted: BN;
  totalVolume: BN;
  totalFeesCollected: BN;
  feeBps: number;
  paused: boolean;
}

export function usePvpGame() {
  const { publicKey } = useWallet();
  const { connection } = useConnection();
  const anchorWallet = useAnchorWallet();

  // -------------------------------------------------------------------------
  // Local UI state
  //
  // The original hook did not expose any stateful values to indicate loading
  // status or to provide lists of open matches.  Consumers such as the Game
  // Lobby and CreateMatchModal attempted to read properties like
  // `openMatches`, `isLoading` or `isCreatingMatch` from the return value of
  // this hook and subsequently crashed.  To support those patterns we track
  // the relevant bits of state here and update them as side effects of the
  // underlying RPC calls.  See the return statement at the bottom of the
  // hook for the exported API.
  const [openMatches, setOpenMatches] = useState<MatchData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  // Holds matches where the connected wallet is either player1 or player2.  This
  // mirrors the openMatches state and is refreshed whenever the wallet or
  // program changes, or after any mutating action.  Consumers can read this
  // via the `myMatches` property returned from the hook.
  const [myMatches, setMyMatches] = useState<MatchData[]>([]);
  const [isCreatingMatch, setIsCreatingMatch] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const [isCanceling, setIsCanceling] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);
  // placeholder for a submitting flag (used for submitResult when implemented)
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Create provider and program
  const provider = useMemo(() => {
    if (!anchorWallet) return null;
    return new AnchorProvider(connection, anchorWallet, {
      preflightCommitment: 'processed',
      commitment: 'confirmed',
    });
  }, [connection, anchorWallet]);

  const program = useMemo(() => {
    if (!provider) return null;
    return new Program<PvpGame>(idl as PvpGame, provider);
  }, [provider]);

  // Derive platform config PDA
  const platformConfigPDA = useMemo(() => {
    const [pda] = PublicKey.findProgramAddressSync(
      [Buffer.from(PLATFORM_CONFIG_SEED)],
      PROGRAM_ID
    );
    return pda;
  }, []);

  // Generate match PDA from match ID
  const getMatchPDA = useCallback((matchId: Uint8Array) => {
    const [pda] = PublicKey.findProgramAddressSync(
      [Buffer.from(MATCH_SEED), matchId],
      PROGRAM_ID
    );
    return pda;
  }, []);

  // Generate escrow PDA from match PDA
  const getEscrowPDA = useCallback((matchPDA: PublicKey) => {
    const [pda] = PublicKey.findProgramAddressSync(
      [Buffer.from(ESCROW_SEED), matchPDA.toBuffer()],
      PROGRAM_ID
    );
    return pda;
  }, []);

  // Generate random match ID
  const generateMatchId = useCallback(() => {
    return crypto.getRandomValues(new Uint8Array(32));
  }, []);

  // Fetch platform stats
  const fetchPlatformStats = useCallback(async (): Promise<PlatformStats | null> => {
    if (!program) return null;
    try {
      const config = await program.account.platformConfig.fetch(platformConfigPDA);
      return {
        totalMatches: config.totalMatches,
        matchesCompleted: config.matchesCompleted,
        totalVolume: config.totalVolume,
        totalFeesCollected: config.totalFeesCollected,
        feeBps: config.feeBps,
        paused: config.paused,
      };
    } catch (error) {
      console.log('Platform not initialized:', error);
      return null;
    }
  }, [program, platformConfigPDA]);

  // Fetch all open matches (waiting for opponent)
  const fetchOpenMatches = useCallback(async (): Promise<MatchData[]> => {
    if (!program) return [];
    try {
      const matches = await program.account.gameMatch.all([
        {
          memcmp: {
            offset: 8 + 32 + 32 + 32 + 8, // Skip to status field
            // Anchor encodes enums by discriminant starting at 0.  The first variant
            // in the MatchStatus enum is WaitingForOpponent, which has a
            // discriminant of 0.  Using '0' here filters for matches that have
            // not yet been joined by a second player.  The previous value of
            // '1' incorrectly filtered for the InProgress variant and resulted in
            // no open matches being returned.
            bytes: '0',
          },
        },
      ]);
      return matches.map((m) => ({
        publicKey: m.publicKey,
        ...m.account,
      })) as MatchData[];
    } catch (error) {
      console.error('Error fetching matches:', error);
      return [];
    }
  }, [program]);

  // Fetch matches for current user
  const fetchMyMatches = useCallback(async (): Promise<MatchData[]> => {
    if (!program || !publicKey) return [];
    try {
      // Fetch matches where user is player1 or player2
      const allMatches = await program.account.gameMatch.all();
      return allMatches
        .filter(
          (m) =>
            m.account.player1.equals(publicKey) ||
            m.account.player2.equals(publicKey)
        )
        .map((m) => ({
          publicKey: m.publicKey,
          ...m.account,
        })) as MatchData[];
    } catch (error) {
      console.error('Error fetching my matches:', error);
      return [];
    }
  }, [program, publicKey]);

  // Fetch single match by ID
  const fetchMatch = useCallback(
    async (matchPDA: PublicKey): Promise<MatchData | null> => {
      if (!program) return null;
      try {
        const match = await program.account.gameMatch.fetch(matchPDA);
        return {
          publicKey: matchPDA,
          ...match,
        } as MatchData;
      } catch (error) {
        console.error('Error fetching match:', error);
        return null;
      }
    },
    [program]
  );

  // -------------------------------------------------------------------------
  // Side effects
  //
  // When the program becomes available (e.g. the wallet connects) we load
  // any open matches from chain.  This keeps the lobby state up to date.  If
  // fetching fails the error is logged and the openMatches array is reset.
  useEffect(() => {
    const load = async () => {
      if (!program) return;
      try {
        setIsLoading(true);
        const matches = await fetchOpenMatches();
        setOpenMatches(matches);
      } catch (err) {
        console.error('Failed to fetch open matches', err);
        setOpenMatches([]);
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [program, fetchOpenMatches]);

  // Load matches for the connected wallet.  This runs whenever the program
  // instance or wallet publicKey changes.  It shares the same isLoading
  // state as the open match fetch; whichever finishes last will determine
  // the final loading indicator.  If either dependency is missing the
  // myMatches array is cleared.
  useEffect(() => {
    const loadMy = async () => {
      if (!program || !publicKey) {
        setMyMatches([]);
        return;
      }
      try {
        setIsLoading(true);
        const matches = await fetchMyMatches();
        setMyMatches(matches);
      } catch (err) {
        console.error('Failed to fetch my matches', err);
        setMyMatches([]);
      } finally {
        setIsLoading(false);
      }
    };
    loadMy();
  }, [program, publicKey, fetchMyMatches]);

  // Create a new match
  const createMatch = useCallback(
    async (stakeAmountSol: number): Promise<{ tx: string; matchId: Uint8Array; matchPDA: PublicKey }> => {
      if (!program || !publicKey) {
        throw new Error('Wallet not connected');
      }

      setIsCreatingMatch(true);
      const matchId = generateMatchId();
      const matchPDA = getMatchPDA(matchId);
      const escrowPDA = getEscrowPDA(matchPDA);
      const stakeAmount = new BN(stakeAmountSol * LAMPORTS_PER_SOL);

      const tx = await program.methods
        .createMatch(stakeAmount, Array.from(matchId))
        .accounts({
          platformConfig: platformConfigPDA,
          gameMatch: matchPDA,
          escrow: escrowPDA,
          player1: publicKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();
      // refresh open matches after creating a new one
      try {
        const matches = await fetchOpenMatches();
        setOpenMatches(matches);
        // also refresh the user's matches list since they just created a match
        const my = await fetchMyMatches();
        setMyMatches(my);
      } catch (err) {
        console.error('Failed to refresh matches after createMatch', err);
      }
      setIsCreatingMatch(false);

      return { tx, matchId, matchPDA };
    },
    [program, publicKey, platformConfigPDA, generateMatchId, getMatchPDA, getEscrowPDA, fetchOpenMatches]
  );

  // Join an existing match
  const joinMatch = useCallback(
    async (matchPDA: PublicKey): Promise<string> => {
      if (!program || !publicKey) {
        throw new Error('Wallet not connected');
      }

      setIsJoining(true);
      const escrowPDA = getEscrowPDA(matchPDA);
      const tx = await program.methods
        .joinMatch()
        .accounts({
          platformConfig: platformConfigPDA,
          gameMatch: matchPDA,
          escrow: escrowPDA,
          player2: publicKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();
      // refresh open matches list after joining (the match will no longer be open)
      try {
        const matches = await fetchOpenMatches();
        setOpenMatches(matches);
        // refresh my matches after joining as player2
        const my = await fetchMyMatches();
        setMyMatches(my);
      } catch (err) {
        console.error('Failed to refresh matches after joinMatch', err);
      }
      setIsJoining(false);
      return tx;
    },
    [program, publicKey, platformConfigPDA, getEscrowPDA, fetchOpenMatches]
  );

  // Cancel a match (only if no opponent)
  const cancelMatch = useCallback(
    async (matchPDA: PublicKey): Promise<string> => {
      if (!program || !publicKey) {
        throw new Error('Wallet not connected');
      }

      setIsCanceling(true);
      const escrowPDA = getEscrowPDA(matchPDA);
      const tx = await program.methods
        .cancelMatch()
        .accounts({
          gameMatch: matchPDA,
          escrow: escrowPDA,
          player1: publicKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();
      // refresh open matches (match removed)
      try {
        const matches = await fetchOpenMatches();
        setOpenMatches(matches);
        // refresh my matches list; the cancelled match will be removed
        const my = await fetchMyMatches();
        setMyMatches(my);
      } catch (err) {
        console.error('Failed to refresh matches after cancelMatch', err);
      }
      setIsCanceling(false);
      return tx;
    },
    [program, publicKey, getEscrowPDA, fetchOpenMatches]
  );

  // Claim winnings (winner only)
  const claimWinnings = useCallback(
    async (matchPDA: PublicKey): Promise<string> => {
      if (!program || !publicKey) {
        throw new Error('Wallet not connected');
      }
      setIsClaiming(true);
      const escrowPDA = getEscrowPDA(matchPDA);
      // fetch platform config to get treasury pubkey
      const platformConfig = await program.account.platformConfig.fetch(platformConfigPDA);
      const tx = await program.methods
        .claimWinnings()
        .accounts({
          platformConfig: platformConfigPDA,
          gameMatch: matchPDA,
          escrow: escrowPDA,
          treasury: platformConfig.treasury,
          winner: publicKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();
      // refresh open matches (match claimed is no longer open)
      try {
        const matches = await fetchOpenMatches();
        setOpenMatches(matches);
        // refresh my matches list so that the claimed match status updates
        const my = await fetchMyMatches();
        setMyMatches(my);
      } catch (err) {
        console.error('Failed to refresh matches after claimWinnings', err);
      }
      setIsClaiming(false);
      return tx;
    },
    [program, publicKey, platformConfigPDA, getEscrowPDA, fetchOpenMatches]
  );

  return {
    program,
    provider,
    platformConfigPDA,
    getMatchPDA,
    getEscrowPDA,
    generateMatchId,
    fetchPlatformStats,
    fetchOpenMatches,
    fetchMyMatches,
    fetchMatch,
    createMatch,
    joinMatch,
    cancelMatch,
    claimWinnings,
    // reactive UI state
    openMatches,
    myMatches,
    isLoading,
    isCreatingMatch,
    isJoining,
    isCanceling,
    isClaiming,
    isSubmitting,
  };
}
