'use client';

import { FC } from 'react';
import { usePvpGame } from '@/hooks/usePvpGame';
import { GameMatch } from '@/idl/pvp_game';
import { LAMPORTS_PER_SOL, PublicKey } from '@solana/web3.js';
import { useWallet } from '@solana/wallet-adapter-react';

interface MatchCardProps {
  match: {
    publicKey: any;
    account: GameMatch;
  };
}

export const MatchCard: FC<MatchCardProps> = ({ match }) => {
  const { publicKey } = useWallet();
  const {
    joinMatch,
    // submitResult is not yet implemented in this hook but would set `isSubmitting` when added
    claimWinnings,
    cancelMatch,
    isJoining,
    isSubmitting,
    isClaiming,
    isCanceling,
  } = usePvpGame();

  const isPlayer1 = publicKey?.equals(match.account.player1);
  const isPlayer2 = publicKey?.equals(match.account.player2);

  // Anchor represents Rust enums as objects with a single variant key.  For example:
  // { waitingForOpponent: {} } or { inProgress: {} }  We derive booleans for each
  // possible status and use them to determine what actions are permitted.
  const status = match.account.status as any;
  const isWaiting = status && 'waitingForOpponent' in status;
  const isInProgress = status && 'inProgress' in status;
  const isCompleted = status && 'completed' in status;
  const isCancelled = status && 'cancelled' in status;
  const isClaimedStatus = status && 'claimed' in status;

  const canJoin = !isPlayer1 && !isPlayer2 && isWaiting;
  const canPlay = (isPlayer1 || isPlayer2) && isInProgress;
  const canClaim = (isPlayer1 || isPlayer2) && isCompleted && match.account.winner?.equals(publicKey!);
  const canCancel = isPlayer1 && isWaiting;

  const renderAction = () => {
    if (canJoin) {
      return (
        <button
          onClick={() => joinMatch(match.publicKey)}
          className="btn-primary w-full"
          disabled={isJoining}
        >
          Join Match
        </button>
      );
    }
    if (canPlay) {
      // submitting results requires a server authority; this action would normally
      // trigger an off-chain game flow.  For now disable the button until
      // `submitResult` is implemented.
      return (
        <button className="btn-primary w-full" disabled>
          In Progress
        </button>
      );
    }
    if (canClaim) {
      return (
        <button
          onClick={() => claimWinnings(match.publicKey)}
          className="btn-primary w-full"
          disabled={isClaiming}
        >
          Claim Winnings
        </button>
      );
    }
    if (canCancel) {
      return (
        <button
          onClick={() => cancelMatch(match.publicKey)}
          className="btn-secondary w-full"
          disabled={isCanceling}
        >
          Cancel Match
        </button>
      );
    }
    return null;
  };

  const getStatus = () => {
    if (isWaiting) return <span className="text-green-400">Waiting</span>;
    if (isInProgress) return <span className="text-yellow-400">In Progress</span>;
    if (isCompleted) return <span className="text-red-400">Completed</span>;
    if (isCancelled) return <span className="text-gray-400">Cancelled</span>;
    if (isClaimedStatus) return <span className="text-purple-400">Claimed</span>;
    return <span className="text-gray-500">Unknown</span>;
  };

  return (
    <div className="glass-card p-6 flex flex-col justify-between hover:border-[var(--primary-color)] transition-colors duration-300">
      <div>
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-sm text-[var(--subtext-color)]">Match Stake</p>
            <p className="text-2xl font-bold text-[var(--primary-color)]">{match.account.stakeAmount.toNumber() / LAMPORTS_PER_SOL} SOL</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-[var(--subtext-color)]">Status</p>
            <p className="font-bold">{getStatus()}</p>
          </div>
        </div>

        <div className="space-y-2 text-sm">
          <p>
            <span className="font-semibold text-[var(--subtext-color)]">Player 1:</span>{' '}
            {match.account.player1.toBase58().slice(0, 8)}...
          </p>
          <p>
            <span className="font-semibold text-[var(--subtext-color)]">Player 2:</span>{' '}
            {match.account.player2 && match.account.player2.toBase58() !== '11111111111111111111111111111111'
              ? `${match.account.player2.toBase58().slice(0, 8)}...`
              : 'Waiting...'}
          </p>
          {match.account.winner && match.account.winner.toBase58() !== '11111111111111111111111111111111' && (
            <p>
              <span className="font-semibold text-[var(--subtext-color)]">Winner:</span>{' '}
              {match.account.winner.toBase58().slice(0, 8)}...
            </p>
          )}
        </div>
      </div>
      <div className="mt-6">
        {renderAction()}
      </div>
    </div>
  );
};
